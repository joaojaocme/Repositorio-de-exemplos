<footer>
        &copy; Desenvolvido por Heraldo - O melhor de todos!
    </footer>

</body>
</html>